--QUES1
create table Student(
id int primary key,
sname varchar(50) not null,
semil  varchar(30) unique,
sage int,
marks decimal
)
--1
insert into Student values (1,'Alice','alice@123gmail.com',20,78.5);
insert into Student values (2,'Bob','bob@123gmail.com',22,87.5);
insert into Student values (3,'Cavin','cavin@123gmail.com',24,90.5);
insert into Student values (4,'Dob','dob@123gmail.com',17,85.5);
insert into Student values (5,'Evin','evin@123gmail.com',25,94.5);

select * from Student;
--2
select * from Student where sage>21;
--3
update  Student set semil='rahul@gamil.com' where id=5;
--4
delete  from Student where sage<18;
--rollback;
--5
select * from Student order by marks desc limit 1 offset 1;
---ques2
create table student1(
id int ,
name varchar(50),
age int
);
insert into student1 values(1,'alana',20);
insert into student1 values(2,'bavana',22);
insert into student1 values(3,'cavana',24);
select * from student1;
create table course1(
cor_id int,
sid int,
cor_name varchar(50)
);
insert into course1 values(01,1,'Javafullstack');
insert into course1 values(02,3,'MERNfullstack');
insert into course1 values(03,2,'Pythonfullstack');
--6
select * from course1;
select s. name , c.cor_name from student1 s inner join course1 c on s.id=c.cor_id;


