package GameStores;

public class GameStore01 {

    public void Call_of_Warfare() {
        int sum = 1500;
        System.out.println("The cost is: " + sum);
    }

    public void Speed_Racers() {
        int cost = 1200;
        System.out.println("The cost is: " + cost);
    }

    public void Mystery_Mansion() {
        int cost = 1000;
        System.out.println("The cost is: " + cost);
    }

    public void Pixel_Adventure() {
        int cost = 800;
        System.out.println("The cost is: " + cost);
    }

    public void Puzzle_Mania() {
        int cost = 500;
        System.out.println("The cost is: " + cost);
    }
}
