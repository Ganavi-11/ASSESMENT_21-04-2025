package GameStores;

import java.util.Scanner;

public class Option {
    public static void main(String[] args) {
        GameStore01 options = new GameStore01();
        Scanner sc = new Scanner(System.in);
        int select;

        do {
            System.out.println("\n Enter option between 1 to 6:");
            System.out.println("1. Call of Warfare");
            System.out.println("2. Speed Racers");
            System.out.println("3. Mystery Mansion");
            System.out.println("4. Pixel Adventure");
            System.out.println("5. Puzzle Mania");
            System.out.println("6. Exit");

            select = sc.nextInt();
            switch (select) {
                case 1:
                    System.out.println("Game(s) added to your cart");
                    options.Call_of_Warfare();
                    break;
                case 2:
                    System.out.println("Game(s) added to your cart");
                    options.Speed_Racers();
                    break;
                case 3:
                    System.out.println("Game(s) added to your cart");
                    options.Mystery_Mansion();
                    break;
                case 4:
                    System.out.println("Game(s) added to your cart");
                    options.Pixel_Adventure();
                    break;
                case 5:
                    System.out.println("Game(s) added to your cart");
                    options.Puzzle_Mania();
                    break;
                case 6:
                    System.out.println("You are out of options. Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (select != 6);

        
    }
}
