package pattern;

public class TrianglePattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=5;i++){
		 for (int j = 0; j < (2 * i + 1); j++)
		
		{ System.out.println("*");
		  	
		}
		System.out.println();
	}
	}
}

