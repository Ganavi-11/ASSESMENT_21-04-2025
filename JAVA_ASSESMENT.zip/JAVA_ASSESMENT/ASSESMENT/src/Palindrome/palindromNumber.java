package Palindrome;

import java.util.Scanner;

public class palindromNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number :");
		int num=sc. nextInt();
		 int rev=0;
		 while(num>0) {
			 rev=rev*10+(num%10);
			 num=num/10;
		 }
		 if(num==rev) {
		 System.out.println("reverse"+rev);
		 }
		 else
		 {
			 System.out.println("it is not a palindrome num");
		 }

	}

}
